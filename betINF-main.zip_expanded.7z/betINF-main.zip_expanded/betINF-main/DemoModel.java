import java.util.ArrayList;

public class DemoModel {

    private static ArrayList<Cliente> clientesCadastrados;
    public DemoModel(){
        clientesCadastrados = new ArrayList<Cliente>();
    }

    //fazer cadastro
    public boolean addCliente(Cliente cliente){
        return clientesCadastrados.add(cliente);
    }

    //remover cliente
    public boolean removeClientePeloCPF(int cpf){
        for (Cliente cliente : clientesCadastrados) {
            if(cliente.getCpf() == cpf){
                clientesCadastrados.remove(cliente);
                return true;
            }
        }
        return false;
    }
    
    
    /*
    //nesse metodo? provavelmente no model
    public boolean confirmaLogin(String usuario, String senha){
        if(usuario.equals(usuarioLogin) && senha.equals(senhaLogin)){
            return true;
        }
        else{
            return false;
        }

    }
    */
    
    
}
