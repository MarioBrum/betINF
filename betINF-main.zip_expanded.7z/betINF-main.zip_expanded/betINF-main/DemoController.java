public class DemoController{

    private static DemoView view;
    private static DemoModel model;
    private static boolean logado;


    public DemoController(DemoModel model, DemoView view){
        this.model = model;
        this.view = view;

    }

    public static void main(String [] args){
    	DemoController dc = new DemoController(new DemoModel(), new DemoView());
    	while(true) {
    		if(!logado) {
    			int opcao = dc.view.showOpcoesLogin();
    			switch(opcao) {
    			case 0: 
    				System.exit(0);
    			case 1:
    				
    				break;
    				//caso cliente se cadastra, automaticamente � logado
    			case 2:
    				logado = dc.model.addCliente(dc.view.showCadastro());
    				/*
    				Cliente novoCliente = dc.view.showCadastro();
    				dc.model.addCliente(novoCliente);
    				*/
    				break;
    			default:
    				break;
    		}
    		}
    	}
    	
    }


}