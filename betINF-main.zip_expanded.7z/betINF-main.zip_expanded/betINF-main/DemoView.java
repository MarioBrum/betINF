import java.util.Scanner;
public class DemoView {
    private static Scanner entrada;
    public DemoView(){
        entrada = new Scanner(System.in);
        
    }
    
    //mostra tela de login
    //retorna true caso v� para janela de login
	public int showOpcoesLogin() {
		System.out.println("1. Digite 1 para ir para aba de login: \n" 
						+ "2. Digite 2 para ir para aba de cadastro: \n"
						+ "0. Sair");
		//int entradaTeclado = entrada.nextInt();
		return entrada.nextInt();
	}

	/*
	System.out.println("Usuario: ");
    String usuario = entrada.next();
    ///senha aparece no terminal
    System.out.println("Senha: ");
    String senha = entrada.next();
	*/
	
	protected Cliente showCadastro() {
		System.out.println("Digite o nome: ");
		String nome = entrada.next();
		System.out.println("Digite o cpf: ");
		int cpf = entrada.nextInt();
		System.out.println("Digite o usuario para login: ");
		String usuario = entrada.next();
		System.out.println("Digite a senha para login: ");
		String senha = entrada.next();
		return new Cliente(nome,cpf,usuario,senha);
	}

	private boolean showLogin() {
		return false;
		// TODO Auto-generated method stub
		
	}
}
